# Bot da Loja de Jogos (Discord + Pix/Mercado Pago)

Bot que vende os teus jogos no Discord: o comprador escolhe o jogo, recebe um QR
code Pix **dentro do próprio Discord** (sem ir a nenhum site), paga, e assim que
o Mercado Pago confirma o pagamento o bot envia a chave automaticamente por DM
e (opcionalmente) atribui um cargo de "Cliente".

Os comandos de administração usam prefixo `!` (configurável), não slash commands.

## O que precisas de ter antes de começar

1. **Node.js 18+** instalado.
2. Uma **aplicação/bot no Discord**: https://discord.com/developers/applications
   - Cria a aplicação → menu lateral **"Bot"** → "Add Bot" → copia o **Token**.
   - Na mesma página "Bot", em **"Privileged Gateway Intents"**, ativa o
     **"MESSAGE CONTENT INTENT"** — sem isto o bot não consegue ler os comandos `!`.
   - Em "OAuth2 → URL Generator" marca `bot`, permissões `Send Messages`,
     `Read Message History`, `Attach Files`, `Manage Roles` (se usares cargo
     automático), e usa o link gerado para convidar o bot para o teu servidor.
3. Uma **conta Mercado Pago** (pessoa/empresa que vai receber o dinheiro):
   - Vai a https://www.mercadopago.com.br/developers/panel/app
   - Cria uma aplicação → copia o **Access Token** (usa o de teste primeiro,
     depois troca para o de produção quando estiver tudo a funcionar).
4. Um sítio para **alojar o bot 24h com URL pública** (VPS, Railway, Render, etc.).
   Isto continua a ser necessário mesmo sem checkout por site: é o Mercado Pago
   a avisar o teu bot "o pagamento X foi aprovado", e para isso ele precisa de
   conseguir chamar o teu servidor.

## Instalação

```bash
npm install
cp .env.example .env
```

Preenche o `.env`:

- `DISCORD_TOKEN` — token do bot
- `GUILD_ID` — ID do teu servidor (ativa o "modo de desenvolvedor" no Discord →
  botão direito no servidor → Copiar ID)
- `LOG_CHANNEL_ID` — canal onde o bot avisa de cada venda (opcional, recomendado)
- `PREFIX` — prefixo dos comandos, por defeito `!`
- `MP_ACCESS_TOKEN` — access token do Mercado Pago
- `PUBLIC_BASE_URL` — URL pública onde este bot vai estar a correr (ex:
  `https://o-teu-servidor.com`), usada para o Mercado Pago te avisar do pagamento

## Arrancar o bot

```bash
npm start
```

O bot liga-se ao Discord e, ao mesmo tempo, arranca um pequeno servidor HTTP
que recebe a confirmação automática do Mercado Pago em `/webhook/mercadopago`.

**Para testar localmente** antes de teres um servidor público, usa um túnel
como o [ngrok](https://ngrok.com/) (`ngrok http 3000`) e põe o URL que ele te
der em `PUBLIC_BASE_URL`.

## Como usar (dentro do Discord, como admin)

```
!produto-criar "Elden Ring" 49.90 "Chave Steam" @Cliente
```
→ responde com o `ID` do produto (o campo do cargo é opcional).

```
!chave-adicionar 1
```
→ anexa ao mesmo tempo um ficheiro `.txt` com uma chave por linha (uma chave = uma venda).

```
!produtos
```
→ vê o stock de cada jogo.

```
!loja
```
→ publica a montra com um menu de seleção para os clientes comprarem.

## O que acontece numa compra

1. Cliente escolhe o jogo no menu → o bot gera um Pix na hora e mostra o QR
   code e o código "copia e cola" **dentro do Discord** (mensagem só visível
   para ele).
2. Cliente paga o Pix na app do banco dele.
3. O Mercado Pago avisa automaticamente o teu bot (webhook).
4. O bot confirma o pagamento diretamente na API do Mercado Pago (nunca confia
   só no aviso recebido), atribui uma chave nunca usada, envia por DM, marca-a
   como usada (nunca é repetida) e, se definiste um cargo, atribui-o.

## Notas

- As chaves e os pedidos ficam guardados em `loja.db` (SQLite), criado
  automaticamente na primeira vez que corres o bot. Faz backups regulares.
- Se um pagamento for confirmado mas o stock estiver a zero, o bot avisa no
  `LOG_CHANNEL_ID` em vez de falhar silenciosamente — entrega manualmente e
  depois carrega mais chaves com `!chave-adicionar`.
- Pix só funciona em reais (BRL) — os preços são sempre inseridos nessa moeda.
